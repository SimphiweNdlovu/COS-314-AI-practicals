public enum Discriminate {
    h,
    i,
    o
}
